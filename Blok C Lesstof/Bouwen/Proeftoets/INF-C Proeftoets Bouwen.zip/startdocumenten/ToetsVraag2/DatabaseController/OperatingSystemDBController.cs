﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;

namespace ToetsVraag2
{
    class OperatingSystemDBController : DatabaseController
    {


        //TO IMPLEMENT
        public void AddOperatingSystem(OperatingSystem operatingSystem)
        {
        
        }
    }
}
