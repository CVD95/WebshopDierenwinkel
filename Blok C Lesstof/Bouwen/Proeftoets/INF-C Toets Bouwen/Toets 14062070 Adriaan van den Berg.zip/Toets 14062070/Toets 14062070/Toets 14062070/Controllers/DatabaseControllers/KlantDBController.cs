﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Toets.Models;
using MySql.Data.MySqlClient;

namespace Toets.Databasecontrollers
{
    public class KlantDBController : DatabaseController
    {

        public Klant GetKlant(int klantid)
        {
            Klant klant = null;
            try
            {
                conn.Open();

                string selectQueryStudent = @"select * from klant where idklant = @klantid";
                MySqlCommand cmd = new MySqlCommand(selectQueryStudent, conn);

                MySqlParameter klantidParam = new MySqlParameter("@klantid", MySqlDbType.Int32);
                klantidParam.Value = klantid;
                cmd.Parameters.Add(klantidParam);
                cmd.Prepare();

                MySqlDataReader dataReader = cmd.ExecuteReader();

                if (dataReader.Read())
                {
                    klant = GetKlantFromDatabase(dataReader);
                }

            }
            catch (Exception e)
            {
                Console.Write("Klant niet opgehaald: " + e);
                throw e;
            }
            finally
            {
                conn.Close();
            }

            return klant;
        }


        public List<Klant> GetKlanten()
        {
            List<Klant> klanten = new List<Klant>();
            MySqlTransaction trans = null;

            try
            {
                conn.Open();
                trans = conn.BeginTransaction();

                string selectQuery = "select * from klant";
                MySqlCommand cmd = new MySqlCommand(selectQuery, conn, trans);
                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    Klant klant = GetKlantFromDatabase(dataReader);
                    klanten.Add(klant);
                }
            }
            catch (Exception e)
            {
                Console.Write("Ophalen van Klanten mislukt " + e);
                trans.Rollback();
                throw e;
            }
            finally
            {
                conn.Close();
            }

            return klanten;
        }


        public void InsertKlant(Klant klant)
        {
            MySqlTransaction trans = null;
            try
            {
                conn.Open();
                trans = conn.BeginTransaction();
                string insertString = @"insert into klant (naam , woonplaats, geboortedatum , geslacht, beschrijving) 
                                               values (@naam, @woonplaats, @geboortedatum, @geslacht, @beschrijving)";

                MySqlCommand cmd = new MySqlCommand(insertString, conn);
                MySqlParameter naamParam = new MySqlParameter("@naam", MySqlDbType.VarChar);
                MySqlParameter woonplaatsParam = new MySqlParameter("@woonplaats", MySqlDbType.VarChar);
                MySqlParameter geboortedatumParam = new MySqlParameter("@geboortedatum", MySqlDbType.DateTime);
                MySqlParameter geslachtParam = new MySqlParameter("@geslacht", MySqlDbType.VarChar);
                MySqlParameter beschrijvingParam = new MySqlParameter("@beschrijving", MySqlDbType.VarChar);


                naamParam.Value = klant.Naam;
                woonplaatsParam.Value = klant.Woonplaats;
                geboortedatumParam.Value = klant.Geboortedatum;
                geslachtParam.Value = klant.geslacht;
                beschrijvingParam.Value = klant.beschrijving;

                cmd.Parameters.Add(naamParam);
                cmd.Parameters.Add(woonplaatsParam);
                cmd.Parameters.Add(geboortedatumParam);
                cmd.Parameters.Add(geslachtParam);
                cmd.Parameters.Add(beschrijvingParam);


                cmd.Prepare();

                cmd.ExecuteNonQuery();

                trans.Commit();

            }
            catch (Exception e)
            {
                trans.Rollback();
                Console.Write("Klant niet toegevoegd: " + e);
                throw e;
            }
            finally
            {
                conn.Close();
            }
        }

    }
}
