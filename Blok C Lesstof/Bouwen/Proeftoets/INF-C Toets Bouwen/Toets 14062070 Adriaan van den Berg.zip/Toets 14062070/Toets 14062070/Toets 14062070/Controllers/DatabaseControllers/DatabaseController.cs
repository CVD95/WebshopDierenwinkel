﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using Toets.Models;


namespace Toets.Databasecontrollers
{
    public abstract class DatabaseController
    {
        protected MySqlConnection conn;

        public DatabaseController()
        {
            conn = new MySqlConnection("Server=localhost;Database=dating;Uid=root;Pwd=admin;");
        }

        protected Klant GetKlantFromDatabase(MySqlDataReader dataReader)
        {
            int klantId = dataReader.GetInt32("idklant");
            string Klantnaam = dataReader.GetString("naam");       
            string Woonplaats = dataReader.GetString("woonplaats");
            DateTime Geboortedatum = dataReader.GetDateTime("geboortedatum");


            Klant klant = new Klant { Naam = Klantnaam, Geboortedatum = Geboortedatum, Woonplaats = Woonplaats };
            return klant;
        }
    }

        
}
